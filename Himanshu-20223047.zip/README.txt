--------------------------------------------------Web Technology-Advance Java Term Project-------------------------------------------------------------------------------

Submitted By: 
Name: Himanshu
Roll no:20223047
MCA IV Semester                                                                                                                                   

----------------------------------------------------------------README--------------------------------------------------------------------------------------------

## topic: Online mobile shopping website

## Plateform—Eclipse IDE.(must download mysql connector)
   Server-tomcat
Technology Front-End:- html, CSS, JavaScript, 
Language- Servlet, JSP and java.
Data Base- MYSQL.

Project Functionality-
• Registration/signup.
• Log in/log out.
• Home.
• New mobile.
• Company wise.
➢ Apple.
➢ Samsung.
➢ Vivo.
• About.

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------